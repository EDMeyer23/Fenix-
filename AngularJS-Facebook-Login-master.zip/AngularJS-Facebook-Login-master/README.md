This is a methodology which connects via facebook and provides a system to check against some database. 
When the user get identified the javascript part of the app, copies the php info gathered.
I'm posting this here in order to find the best solutions for the login process in an app.
I'm using php for the server side, but that could easily be implemented with some other language as well.

Have fun.
